<?php


session_start();

try {
    // On se connecte à MySQL
    $base = new PDO('mysql:host=localhost;dbname=bdd_icare;port=3308;charset=utf8', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
} catch (Exception $e) {
    // En cas d'erreur, on affiche un message et on arrête tout
    die('Erreur : ' . $e->getMessage());
}


 ?>

 <?php 

    remove($base, $_SESSION['username']);
    //mailConfirmation($base);
    header('Location: ../../vitrine/php/accueil.php');


function remove($base,$pseudo){

    $identite = $base->prepare('DELETE FROM identite WHERE `Nom d\'utilisateur`=:Username');
    $identite-> execute(array('Username'=>$pseudo));

}

 
 
 

 
 ?>