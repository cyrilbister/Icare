 <?php


session_start();

try {
    // On se connecte à MySQL
    $base = new PDO('mysql:host=localhost;dbname=bdd_icare;port=3308;charset=utf8', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
} catch (Exception $e) {
    // En cas d'erreur, on affiche un message et on arrête tout
    die('Erreur : ' . $e->getMessage());
}


 ?>

 <?php 

 function test_email($base, $mail){

    $reponse = $base->prepare('SELECT COUNT(*) FROM identite WHERE `Adresse email` = :mail  ');
    $reponse-> execute(array('mail' => $mail));
    $donnees = $reponse->fetch();
    $reponse->closeCursor(); // Termine le traitement de la requête

    return $donnees['COUNT(*)'];

}

function test_identite($base, $nom, $prenom, $rue, $ville){
    $reponse = $base->prepare('SELECT COUNT(*) FROM identite WHERE `Nom` = :nom AND `Prénom` = :prenom AND `N° Identité` = (SELECT `N° d\'adresse` FROM adresse WHERE `Ville`= :ville AND `Nom de rue`= :rue)');
    $reponse-> execute(array('nom' => $nom, 'prenom' => $prenom, 'rue' => $rue, 'ville' => $ville));
    $donnees = $reponse->fetch();
    $reponse->closeCursor(); // Termine le traitement de la requête

    return $donnees['COUNT(*)'];

}

function test_username($base, $pseudo){
    $reponse = $base->prepare('SELECT COUNT(*) FROM identite WHERE `Nom d\'utilisateur` = :pseudo');
    $reponse-> execute(array('pseudo' => $pseudo));
    $donnees = $reponse->fetch();
    $reponse->closeCursor(); // Termine le traitement de la requête

    return $donnees['COUNT(*)'];

}

function test_tel($base, $tel){
    $reponse = $base->prepare('SELECT COUNT(*) FROM identite WHERE `Numéro de téléphone` = :tel');
    $reponse-> execute(array('tel' => $tel));
    $donnees = $reponse->fetch();
    $reponse->closeCursor(); // Termine le traitement de la requête

    return $donnees['COUNT(*)'];

}

function remplissageCorrect($base, $nom, $prenom,$tel, $pseudo, $mail, $pass1, $pass2){


    if (test_email($base,$mail) != 1){

        $_SESSION['message_erreur']="Cette adresse mail est déjà reliée à un compte !";
        header('Location: compte_gestionnaire.php');

    }

    elseif (test_username($base, $pseudo) >= 1){
        $_SESSION['message_erreur']="Ce nom d'utilisateur est déjà relié à un compte !";
        header('Location: compte_gestionnaire.php');

    }

   
    elseif ($pass1 != $pass2) {

        $_SESSION['message_erreur']="Les mots de passe ne sont pas similaires !";
        header('Location: compte_gestionnaire.php');

    }
    elseif (test_tel($base, $tel) >= 1) {
        $_SESSION['message_erreur']="Un compte à votre nom et adresse postale existe déjà, veuillez vérifier la base de donnée ou contacter un administrateur pour éviter les duplicatas !";
        header('Location: compte_gestionnaire.php');

    }
    else if (!isset($nom, $prenom, $pseudo, $tel, $mail, $pass1, $pass2)) {
        $_SESSION['message_erreur']="Veuillez compléter tous les champs requis !";
        header('Location: compte_gestionnaire.php');
    }
    else{

        insertion($base, $_POST['nom_inc'], $_POST['prénom_inc'], $_POST['num_de_tel_inc'],$_POST['pseudo_inc'], $_POST['mail_inc'], $_POST['pass1_inc']);
        //mailConfirmation($base);
        header('Location: compte_gestionnaire.php');
    }

}

remplissageCorrect($base, $_POST['nom_inc'], $_POST['prénom_inc'], $_POST['num_de_tel_inc'],$_POST['pseudo_inc'], $_POST['mail_inc'], $_POST['pass1_inc'], $_POST['pass2_inc']);


function get_identite($base, $id){

    $reponse = $base->prepare('SELECT `N° Identité` FROM identite WHERE `Nom d\'utilisateur`=:pseudo');
    $reponse-> execute(array('pseudo'=> $_SESSION['username']));
    $donnees = $reponse->fetch();
    $reponse->closeCursor(); // Termine le traitement de la requête

    return $donnees['N° Identité'];

 }

function insertion($base, $nom, $prenom, $tel, $pseudo, $mail, $pass1){

    $identite = $base->prepare('UPDATE identite SET `Adresse email` = :mail, `Nom`=:nom, `Prénom`=:prenom, `Mot de passe`=:mdp, `Numéro de téléphone`=:tel, `Actif`=:actif WHERE `Nom d\'utilisateur`=:Username');
    $identite-> execute(array('mail' => $mail, 'nom' => $nom, 'prenom' => $prenom, 'mdp' => $pass1, 'tel'=>$tel, 'actif' => "Actif", 'Username'=>$_SESSION['username']));

    /*$adresse = $base->prepare('UPDATE adresse (`Numéro de bâtiment`, `Nom de rue`, `Code postal`, `Ville`, `Pays`) VALUES (:batiment, :rue, :code_postal, :ville, :pays)');
    $adresse-> execute(array('batiment' => $batiment, 'rue' => $rue, 'code_postal' => $code_postal, 'ville' => $ville, 'pays' => $pays));*/

}

function update_pseudo($base, $pseudo){

    $reponse = $base->prepare('UPDATE identite SET `Nom d\'utilisateur`=:new WHERE `N° Identité`=:id');
    $reponse-> execute(array('new' => $pseudo, 'id'=> get_identite($base, $_SESSION['username'])));
    $reponse->closeCursor(); // Termine le traitement de la requête

    $_SESSION['username'] = $pseudo;

    

}





update_pseudo($base, $_POST['pseudo_inc']);


 
 ?>