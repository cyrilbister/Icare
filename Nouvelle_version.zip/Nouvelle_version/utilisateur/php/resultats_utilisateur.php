<?php


session_start();

try {
    // On se connecte à MySQL
    $base = new PDO('mysql:host=localhost;dbname=bdd_icare;port=3308;charset=utf8', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
} catch (Exception $e) {
    // En cas d'erreur, on affiche un message et on arrête tout
    die('Erreur : ' . $e->getMessage());
}


?>
<?php
function resultats($base)
{

    $audition = '';
    $tonalite = '';
    $temp = '';
    $data1 = '';

    $reponse = $base->prepare('SELECT `*` FROM resultats_test');
    $reponse->execute();

    while ($donnees = $reponse->fetch()) {

        $tonalite = $tonalite . '' . $donnees['Tonalité'] . ',' ;
        $audition = $audition . '' . $donnees['Audition'] . ',' ;
        $temp = $temp . '' . $donnees['Température'] . ',' ;
        $data1 = $data1 . $audition . $temp . $tonalite;

    }


    $reponse->closeCursor(); // Termine le traitement de la requête
    $data1 = trim($data1,",");
    return $data1;

}

?>



<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Consulter les tests</title>
    <link rel= "stylesheet" href="../../header_footer/header_connecte.css" media="all" type="text/css">
    <link rel= "stylesheet" href="../css/compte_utilisateur.css" media="all" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
    <script src = "https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>


  </head>
  <header>
    <div class="bande">
        <nav class="utilisateur">
            <ul>
                <li class="rubriques" ><a href="../../login/php/login.php">Deconnexion</a></li>
                <li class="rubriques"><a href="../php/compte_utilisateur.php">Mon compte</a></li>
                <!-- lien vers les paramètres du comptes (différent pour chaque type de compte) -->
            </ul>
        </nav>
    </div>
    <div class="menu">
        <nav class="page-accueil">
          <ul>
            <li class="rubriques" ><a href="../../vitrine/php/accueil.php">Accueil</a></li>
            <li class="rubriques" ><a href="../../vitrine/html/infinite_measures.html">Infinite Measures & Vous</a></li>
            <li class="rubriques"><a href="../../vitrine/html/equipe.html">Notre Equipe</a></li>
            <li class="rubriques"><a href="stats.html">Nos Statistiques</a></li>
            <li class="rubriques"><a href="../php/forum_utilisateur.php">Forum</a></li>
        </ul>
        </nav>
    </div>
    <div class="perso">
        <nav class="page-accueil">
            <ul>
              <li class="rubriques1" ><a href="tbd_utilisateur.html">Tableau de bord</a></li>
              <li class="rubriques1" ><a href="resultats_utilisateur.html">Mes résultats</a></li>
              <li class="rubriques1"><a href="messagerie_utilisateur.html">Messagerie</a></li>
            </ul>
        </nav>
    </div>
</header>


  <body>

  <h2><?php echo $_SESSION['Username'];?></h2>
<h3>TEST REUSSI</h3>
<p id="monScore">Mon score : <span class="percent">0</span>/200</p>

<div class="scroll-arrow">
    <a href="resultats_utilisateur.php#flexBox"><img src="https://cssanimation.rocks/levelup/public/images/downarrow.png" width="50"></a>
</div>


<div id = "flexBox" class ="flexBox">
    <div class="container">

        <canvas id="myChart"></canvas>

    </div>


    <div class="container">

        <canvas id="myResult"></canvas>

    </div>

    <div class="container">

        <canvas id="myStuff"></canvas>

    </div>

    <div class="container">

        <canvas id="myStuff"></canvas>

    </div>

</div>






<script>

    Chart.defaults.global.defaultFontFamily = 'Lato';
    Chart.defaults.global.defaultFontSize = 18;
    Chart.defaults.global.defaultFontColor = '#777';
    Chart.defaults.global.elements.point.radius = 6;
    Chart.defaults.global.elements.point.backgroundColor = 'rgba(35, 165, 246, 0.9)';
    Chart.defaults.global.elements.line.backgroundColor='rgb(135,206,250,0.7)';
    Chart.defaults.global.elements.line.borderColor='rgb(35,165,246,0.9)';



    let myChart = document.getElementById('myChart').getContext('2d');
    let myResult = document.getElementById('myResult').getContext('2d');

    let percentSuccessChart = new Chart(myChart, {

        type:'bar',
        data:{
            labels:[16,20,25,30,35,40,45,50,55,60,65,70],
            datasets:[{
                label:'Notes',
                data:[
                    <?php echo resultats($base);?>
                ],
                pointHoverRadius:9
            }]


        },
        options: {
            responsive: true,
            
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }   
    });
    

    let percentResultChart = new Chart(myResult, {

        type:'doughnut',
        data:{
            labels:[16,20,25,30,35,40,45],
            datasets:[{
                label:'',
                data:[8,2,2,2,2,2,2
                ],
            
            }]


        },
        options:{
            responsive: false


        }
    });


    // Use requestAnimationFrame with setTimeout fallback
    window.requestAnimFrame = (function () {
        return  window.requestAnimationFrame ||
            window.webkitRequestAnimationFrame ||
            window.mozRequestAnimationFrame ||
            window.oRequestAnimationFrame ||
            window.msRequestAnimationFrame ||
            function (callback) {
                window.setTimeout(callback, 1000 / 60);
            };
    })();

    var percentEl = document.querySelector('.percent');
    var max = 145;

    (function animloop() {
        if (percentEl.innerHTML >= max) { return; } //Stop recursive when max reach
        requestAnimFrame(animloop);
        percentEl.innerHTML++;
    })();


</script>
  </body>


  <footer class="footer-distributed">

    <div class="footer-left">
            <h3>I<span>Care</span></h3>
            <p class="footer-links">
              <a href="../../vitrine/html/faq.html">FAQ</a>
            .
            <a href="mentions.html">Mentions Légales</a>
        </br>



            <a href="#">Langues</a> -

            <a href="#2">Anglais</a>
        .
            <a href="#2">Français</a>


            </p>

            <p class="footer-company-name">Icare &copy; 2020</p>
            </div>

            <div class="footer-center">

            <div>
            <i class="fa fa-map-marker"></i>
            <p>10 Rue de Vanves</br> Issy-les-Moulineaux, France</p>
            </div>

            <div>
            <i class="fa fa-phone"></i>
            <p>+33 6 68 61 24 99</p>
            </div>

            <div>
            <i class="fa fa-envelope"></i>
            <p><a href="mailto:support@company.com">youandicare.supp@gmail.com</a></p>
            </div>

            </div>

            <div class="footer-right">

            <p class="footer-company-about">
            <span>About the company</span>
            <iframe class="API" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2626.7658445478332!2d2.2776649150477297!3d48.82452897928419!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e670797ea4730d%3A0xe0d3eb2ad501cb27!2sISEP!5e0!3m2!1sfr!2sfr!4v1583759492983!5m2!1sfr!2sfr" width="400" height="200" frameborder="0" style="border:0;" allowfullscreen=""></iframe>

            </p>
            </div>
  </footer>
</html>