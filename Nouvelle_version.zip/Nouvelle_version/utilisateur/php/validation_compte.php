<?php


session_start();

try {
    // On se connecte à MySQL
    $base = new PDO('mysql:host=localhost;dbname=bdd_icare;port=3308;charset=utf8', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
} catch (Exception $e) {
    // En cas d'erreur, on affiche un message et on arrête tout
    die('Erreur : ' . $e->getMessage());
}


 ?>

 <?php 

 function test_email($base, $mail){

    $reponse = $base->prepare('SELECT COUNT(*) FROM identite WHERE `Adresse email` = :mail  ');
    $reponse-> execute(array('mail' => $mail));
    $donnees = $reponse->fetch();
    $reponse->closeCursor(); // Termine le traitement de la requête

    return $donnees['COUNT(*)'];

}

function test_identite($base, $nom, $prenom, $rue, $ville){
    $reponse = $base->prepare('SELECT COUNT(*) FROM identite WHERE `Nom` = :nom AND `Prénom` = :prenom AND `N° Identité` = (SELECT `N° d\'adresse` FROM adresse WHERE `Ville`= :ville AND `Nom de rue`= :rue )');
    $reponse-> execute(array('nom' => $nom, 'prenom' => $prenom, 'rue' => $rue, 'ville' => $ville));
    $donnees = $reponse->fetch();
    $reponse->closeCursor(); // Termine le traitement de la requête

    return $donnees['COUNT(*)'];

}

function test_username($base, $pseudo){
    $reponse = $base->prepare('SELECT COUNT(*) FROM identite WHERE `Nom d\'utilisateur` = :pseudo');
    $reponse-> execute(array('pseudo' => $pseudo));
    $donnees = $reponse->fetch();
    $reponse->closeCursor(); // Termine le traitement de la requête

    return $donnees['COUNT(*)'];

}

function test_tel($base, $tel){
    $reponse = $base->prepare('SELECT COUNT(*) FROM identite WHERE `Numéro de téléphone` = :tel');
    $reponse-> execute(array('tel' => $tel));
    $donnees = $reponse->fetch();
    $reponse->closeCursor(); // Termine le traitement de la requête

    return $donnees['COUNT(*)'];

}

function remplissageCorrect($base, $nom, $prenom, $batiment, $rue, $ville, $code_postal, $pays, $date_naissance, $tel, $pseudo, $mail, $pass1, $pass2, $sexe){


    if (test_email($base,$mail) != 1){

        $_SESSION['message_erreur']="Cette adresse mail est déjà reliée à un compte !";
        header('Location: compte_utilisateur.php');

    }

    elseif (test_username($base, $pseudo) >= 1){
        $_SESSION['message_erreur']="Ce nom d'utilisateur est déjà relié à un compte !";
        header('Location: compte_utilisateur.php');

    }

    elseif ((intval($code_postal) == false)){
        $_SESSION['message_erreur']="Veuillez indiquer un code postal valable !";
        header('Location: compte_utilisateur.php');
    }

    elseif (($code_postal < 0) OR (stripos($code_postal, '**'))){

        $t = fopen('log.txt', 'r+');
        fputs($t, $code_postal);
        fclose($t);

        $_SESSION['message_erreur']="Veuillez indiquer un code postal valable !";
        header('Location: compte_utilisateur.php');
    }


    elseif (intval($batiment) == false){

        $_SESSION['message_erreur']="Veuillez indiquer un numéro de bâtiment entier !";
        header('Location: compte_utilisateur.php');

    }

    elseif (($batiment < 0) OR (stripos($batiment, '*')) OR ($batiment > 10**7)){

        $t = fopen('log.txt', 'r+');
        fputs($t, $code_postal);
        fclose($t);

        $_SESSION['message_erreur']= "Veuillez indiquer un numéro de bâtiment valable !";
        header('Location: compte_utilisateur.php');
    }

    elseif ($pass1 != $pass2) {

        $_SESSION['message_erreur']="Les mots de passe ne sont pas similaires !";
        header('Location: compte_utilisateur.php');

    }
    elseif (test_identite($base, $nom, $prenom, $rue, $ville, $pays) >= 1) {
        $_SESSION['message_erreur']="Un compte à votre nom et adresse postale existe déjà, veuillez vérifier la base de donnée ou contacter un administrateur pour éviter les duplicatas !";
        header('Location: compte_utilisateur.php');

    }
    elseif (test_tel($base, $tel) >= 1) {
        $_SESSION['message_erreur']="Un compte à votre nom et adresse postale existe déjà, veuillez vérifier la base de donnée ou contacter un administrateur pour éviter les duplicatas !";
        header('Location: compte_utilisateur.php');

    }
    else if (!isset($nom, $prenom, $batiment, $rue, $ville, $code_postal, $pays, $date_naissance, $pseudo, $tel, $mail, $pass1, $pass2)) {
        $_SESSION['message_erreur']="Veuillez compléter tous les champs requis !";
        header('Location: compte_utilisateur.php');
    }
    else{
        /*$t = fopen('log.txt', 'r+');
        fputs($t, $code_postal);
        fclose($t);*/

        insertion($base, $_POST['nom_inc'], $_POST['prénom_inc'], $_POST['batiment_inc'], $_POST['rue_inc'], $_POST['ville_inc'], $_POST['code_postal_inc'], $_POST['pays_inc'],$_POST['date_naissance_inc'],$_POST['num_de_tel_inc'],$_POST['pseudo_inc'], $_POST['mail_inc'], $_POST['pass1_inc'], $_POST['sexe_inc']);
        //mailConfirmation($base);
        header('Location: compte_utilisateur.php');
    }

}


function insertion($base, $nom, $prenom, $batiment, $rue, $ville, $code_postal, $pays, $date_naissance, $tel, $pseudo, $mail, $pass1, $sexe){

    $identite = $base->prepare('UPDATE identite SET `Adresse email` = :mail, `Nom`=:nom, `Prénom`=:prenom, `Mot de passe`=:mdp, `Date de naissance`=:date_naissance, `Numéro de téléphone`=:tel, `Actif`=:actif, `Sexe`=:sexe WHERE `Nom d\'utilisateur`=:Username');
    $identite-> execute(array('mail' => $mail, 'nom' => $nom, 'prenom' => $prenom, 'mdp' => $pass1, "date_naissance" => $date_naissance, 'tel'=>$tel, 'actif' => "Actif", 'sexe'=>$sexe, 'Username'=>$_SESSION['username']));

    /*$adresse = $base->prepare('UPDATE adresse (`Numéro de bâtiment`, `Nom de rue`, `Code postal`, `Ville`, `Pays`) VALUES (:batiment, :rue, :code_postal, :ville, :pays)');
    $adresse-> execute(array('batiment' => $batiment, 'rue' => $rue, 'code_postal' => $code_postal, 'ville' => $ville, 'pays' => $pays));*/

}

remplissageCorrect($base, $_POST['nom_inc'], $_POST['prénom_inc'], $_POST['batiment_inc'], $_POST['rue_inc'], $_POST['ville_inc'], $_POST['code_postal_inc'], $_POST['pays_inc'],$_POST['date_naissance_inc'],$_POST['num_de_tel_inc'],$_POST['pseudo_inc'], $_POST['mail_inc'], $_POST['pass1_inc'], $_POST['pass2_inc'], $_POST['sexe_inc']);

 function get_identite($base, $id){

    $reponse = $base->prepare('SELECT `N° Identité` FROM identite WHERE `Nom d\'utilisateur`=:pseudo');
    $reponse-> execute(array('pseudo'=> $_SESSION['username']));
    $donnees = $reponse->fetch();
    $reponse->closeCursor(); // Termine le traitement de la requête

    return $donnees['N° Identité'];

 }
 
 
function update_email($base, $mail){

    $reponse = $base->prepare('UPDATE identite SET `Adresse email`=:mail WHERE `Nom d\'utilisateur`=:pseudo');
    $reponse-> execute(array('mail' => $mail, 'pseudo'=> $_SESSION['username']));
    $reponse->closeCursor(); // Termine le traitement de la requête

}

function update_nom($base, $nom){

    $reponse = $base->prepare('UPDATE identite SET `Nom`=:nom WHERE `Nom d\'utilisateur`=:pseudo');
    $reponse-> execute(array('nom' => $nom, 'pseudo'=> $_SESSION['username']));
    $reponse->closeCursor(); // Termine le traitement de la requête

}

function update_prenom($base, $prenom){

    $reponse = $base->prepare('UPDATE identite SET `Prénom`=:prenom WHERE `Nom d\'utilisateur`=:pseudo');
    $reponse-> execute(array('prenom' => $prenom, 'pseudo'=> $_SESSION['username']));
    $reponse->closeCursor(); // Termine le traitement de la requête

}


function update_pseudo($base, $pseudo){

    $reponse = $base->prepare('UPDATE identite SET `Nom d\'utilisateur`=:new WHERE `N° Identité`=:id');
    $reponse-> execute(array('new' => $pseudo, 'id'=> get_identite($base, $_SESSION['username'])));
    $reponse->closeCursor(); // Termine le traitement de la requête

    $_SESSION['username'] = $pseudo;

    

}
function update_phone($base, $phone){

    $reponse = $base->prepare('UPDATE identite SET `Numéro de téléphone`=:phone WHERE `Nom d\'utilisateur`=:pseudo');
    $reponse-> execute(array('phone' => $phone, 'pseudo'=> $_SESSION['username']));
    $reponse->closeCursor(); // Termine le traitement de la requête

}
function update_mdp($base, $mdp, $verif_mdp){

    if ($mdp == $verif_mdp){
    $reponse = $base->prepare('UPDATE identite SET `Mot de passe`=:mdp WHERE `Nom d\'utilisateur`=:pseudo');
    $reponse-> execute(array('mdp' => $mdp, 'pseudo'=> $_SESSION['username']));
    $reponse->closeCursor(); // Termine le traitement de la requête

    }
else{

    header("Location: compte_administrateur.php");
}

}




function update($base, $nom, $prenom, $phone, $mail, $mdp, $verif_mdp, $pseudo){

    update_nom($base, $nom);
    update_prenom($base, $prenom);
    update_phone($base, $phone);
    update_email($base, $mail);
    update_mdp($base, $mdp, $verif_mdp);
    update_pseudo($base, $pseudo);
    



    header("Location: compte_administrateur.php");


}

update_pseudo($base, $_POST['pseudo_inc']);

/*update($base, $_POST['nom_inc'], $_POST['prénom_inc'], $_POST['num_de_tel_inc'], $_POST['mail_inc'], $_POST['pass1_inc'], $_POST['pass2_inc'], $_POST['pseudo_inc']);*/
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 ?>