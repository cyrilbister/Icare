 <?php
session_start();

try {
    // On se connecte à MySQL
    $base = new PDO('mysql:host=localhost;dbname=bdd_icare;port=3308;charset=utf8', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
} catch (Exception $e) {
    // En cas d'erreur, on affiche un message et on arrête tout
    die('Erreur : ' . $e->getMessage());
}


?>


<?php


function get_users($base){


    $reponse = $base->prepare('SELECT COUNT(`Actif`) FROM identite WHERE `Actif` = :actifs');
    $reponse->execute(array('actifs'=>"Actif"));
    $donnees = $reponse->fetch();
    $reponse->closeCursor();

    return $donnees['COUNT(`Actif`)'];
}

function get_etat_test($base){

    $reussi = $base->prepare('SELECT COUNT(`Validité`) FROM etat_du_test WHERE `Validité` = :reussi');
    $reussi->execute(array('reussi'=>"Réussi"));
    $resultat = $reussi->fetch();
    $reussi->closeCursor();

    $reponse = $base->prepare('SELECT COUNT(`Validité`) FROM etat_du_test');
    $reponse->execute();
    $donnees = $reponse->fetch();
    $reponse->closeCursor();




    $percent =  $resultat['COUNT(`Validité`)']/$donnees['COUNT(`Validité`)']*100;
    return $percent;

}

function resultats($base)
{

    $audition = 0;
    $tonalite = 0;
    $temp = 0;
    $freq =0;
    $vue=0;
    $reaction=0;
    $counter = 0;


    $reponse = $base->prepare('SELECT `*` FROM resultats_test');
    $reponse->execute();

    while ($donnees = $reponse->fetch()) {

        $tonalite = $tonalite + $donnees['Tonalité'] ;
        $audition = $audition + $donnees['Audition'] ;
        $temp = $temp + $donnees['Température'] ;
        $freq = $freq + $donnees['Fréquence cardiaque'] ;
        $vue = $vue + $donnees['Vue'];
        $reaction = $reaction + $donnees['Temps de réaction'];
        $counter = $counter + 1;


    }

    $tonalite = $tonalite / $counter ;
    $audition = $audition / $counter  ;
    $temp = $temp / $counter ;
    $freq = $freq / $counter ;
    $vue = $vue / $counter;
    $reaction = $reaction / $counter;


    $data1 = $audition . "," . $temp . "," . $tonalite . "," . $freq . "," . $vue . "," . $reaction;


    $reponse->closeCursor(); // Termine le traitement de la requête
    
    return $data1;

}

function score_moyen($base){

    $counter =0;
    $score = 0;

    $reponse = $base->prepare('SELECT `Score total` FROM resultats_test');
    $reponse->execute();

    while ($donnees = $reponse->fetch()) {

        $score = $score + $donnees['Score total'] ;
        $counter = $counter + 1;

    }
    $reponse->closeCursor();

    $score = $score / $counter;
    return $score;
}

function age($base){

    $a16_20 = 0;
    $a20_30 = 0;
    $a30_40 = 0;
    $a40_50 = 0;
    $a50_60 = 0;
    $a60 = 0;

    $reponse = $base->prepare('SELECT `Date de naissance` FROM identite WHERE `Type de compte`=:user');
    $reponse->execute(array('user'=>"Utilisateur"));
    while ($donnees = $reponse->fetch()) {

        $datetime1 = new DateTime($donnees['Date de naissance']);
        $datetime2 = new DateTime('2020-06-03');
        $interval = $datetime1->diff($datetime2);
        $interval = $interval->format('%R%a');
        $interval = str_replace('+', '', $interval);

        $annees = floor($interval/365);
        

        switch ($annees){
            case (16<$annees AND $annees<20):
                $a16_20 += 1;
            break;

            case (20<$annees AND $annees<30):
                $a20_30 += 1;
            break;

            case (30<$annees AND $annees<40):
                $a30_40 += 1;
            break;

            case (40<$annees AND $annees<50):
                $a40_50 += 1;
            break;

            case (50<$annees AND $annees<60):
                $a50_60 += 1;
            break;

            case ($annees>60):
                $a60 += 1;
            break;
            
        }


    }

    $reponse->closeCursor();

    $data = $a16_20 . "," . $a20_30 . "," . $a30_40 . "," . $a40_50 . "," . $a50_60 . "," . $a60;
    


    return $data;

}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Accueil</title>
    <link href="../../header_footer/header_basique.css" rel="stylesheet" media="all" type="text/css">
    <link href="../../header_footer/footer.css" rel="stylesheet" media="all" type="text/css">
    <link href="../css/statistiques.css" rel="stylesheet" media="all" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <script src = "https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
</head>

<header>
    <div class="bande">
        <nav class="utilisateur">
            <ul>
                <li class="rubriques"><a href="../../login/php/login.php">Se connecter</a></li>
                <li class="rubriques"><a href="inscription.php">Création d'un compte</a></li>
            </ul>
        </nav>
    </div>

    <div class="menu">
        <nav class="page-accueil">
            <ul>
                <li class="rubriques"><a href="accueil.php">Accueil</a></li>
                <li class="rubriques"><a href="../html/infinite_measures.html">Infinite Measures & Vous</a></li>
                <li class="rubriques"><a href="equipe.php">Notre Equipe</a></li>
                <li class="rubriques"><a href="statistiques.php">Nos Statistiques</a></li>
                <li class="rubriques"><a href="../../utilisateur/php/forum_utilisateur.php">Forum</a></li>
            </ul>
        </nav>
    </div>

</header>


<body>


<h2>Nos Statistiques</h2>

<div class="scroll-arrow">
    <a href="statistiques.php#flexBox"><img src="https://cssanimation.rocks/levelup/public/images/downarrow.png" width="50"></a>
</div>


<div class ="flexBox">
    <div class="container">

        <canvas id="notesMoyennes"></canvas>
        <h4>Notes moyennes de chaque test psychotechnique</h4>

    </div>


    <div class="container">

        <canvas id="ageRepartition"></canvas>
        <h4>Répartition des classes d'âge de nos utilisateurs</h4>
        

    </div>

   

</div>

<div id="resumeFlex" class ="flexBox">
<p class="resume"><span class="green">0</span>% de réussite aux tests</p>          
    <p class="resume"><span class="percent"><?php echo get_users($base);?></span>+ utilisateurs inscrits</p>
    <p class="resume">Score total moyen : <span id="green" class="green">0</span>/120</p>


</div>

<div id = "flexBox" class ="flexBox">
    <div class="container">

        <canvas id="myChart"></canvas>

    </div>


    <div class="container">

        <canvas id="myResult"></canvas>

    </div>

   

</div>







<script>

    Chart.defaults.global.defaultFontFamily = 'Lato';
    Chart.defaults.global.defaultFontSize = 18;
    Chart.defaults.global.defaultFontColor = '#777';
    Chart.defaults.global.elements.point.radius = 6;
    Chart.defaults.global.elements.point.backgroundColor = 'rgba(35, 165, 246, 0.9)';
    Chart.defaults.global.elements.line.backgroundColor='rgb(135,206,250,0.7)';
    Chart.defaults.global.elements.line.borderColor='rgb(35,165,246,0.9)';

    



    let notesMoyenne = document.getElementById('notesMoyennes').getContext('2d');
    let ageRepartition = document.getElementById('ageRepartition').getContext('2d');

    let percentSuccessChart = new Chart(notesMoyenne, {

        type:'bar',
        data:{
            labels:['Audition','Température','Tonalité','Fréquence cardiaque','Vue','Temps de réaction'],
            datasets:[{
                label:'',
                data:[
                   <?php echo resultats($base);?>
                ],
                backgroundColor :[
                    'rgba(255, 99, 132, 0.6)',
            'rgba(54, 162, 235, 0.6)',
            'rgba(255, 206, 86, 0.6)',
            'rgba(75, 192, 192, 0.6)',
            'rgba(153, 102, 255, 0.6)',
            'rgba(255, 159, 64, 0.6)',
            'rgba(255, 99, 132, 0.6)'
                
                
                
                ],
                
            }]


        },
        options: {
            responsive: true,
            
        scales: {
            xAxes: [{
                   gridLines: {
                       display:false
                   },
                }],
            yAxes: [{
                
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }   
    });
    

    let percentResultChart = new Chart(ageRepartition, {

        type:'doughnut',
        data:{
            labels:['16-20', '20-30', '30-40', '40-50', '50-60','+60'],
            datasets:[{
                label:'',
                data:[
                    <?php echo age($base); ?>
                ],

                backgroundColor :[
                    'rgba(199, 20, 4, 0.8)',
                    'rgba(8, 162, 145, 0.8)',
                    'rgba(255, 99, 132, 0.8)',
                    'rgba(14, 206, 204, 0.8)',
                    'rgba(255, 159, 64, 0.8)',
                    'rgba(75, 202, 123, 0.8)',
                    
                    
                
                
                
                ]

                
                
                
            }]


        },
        options: {
            responsive: true,
            
        scales: {
            xAxes: [{
                   gridLines: {
                       display:false
                   },
                   ticks: {
                display: false
            }
               }],
            yAxes: [{
                gridLines: {
                       display:false
                   },
            ticks: {
                display: false
            }
        }]
        }
    }   
    });


    // Use requestAnimationFrame with setTimeout fallback
    window.requestAnimFrame = (function () {
        return  window.requestAnimationFrame ||
            window.webkitRequestAnimationFrame ||
            window.mozRequestAnimationFrame ||
            window.oRequestAnimationFrame ||
            window.msRequestAnimationFrame ||
            function (callback) {
                window.setTimeout(callback, 1000 / 60);
            };
    })();

    var percentEl = document.querySelector('#green');
    var percentEl2 = document.querySelector('.green');
    var max = <?php echo get_etat_test($base); ?>;

    (function animloop() {
        if (percentEl2.innerHTML >= <?php echo get_etat_test($base); ?>) { return; } //Stop recursive when max reach
        requestAnimFrame(animloop);
        percentEl2.innerHTML++;
    })();

    (function animloop() {
        if (percentEl.innerHTML >= <?php echo score_moyen($base);?>) { return; } //Stop recursive when max reach
        requestAnimFrame(animloop);
        percentEl.innerHTML++;
    })();


</script>
  </body>


</html>