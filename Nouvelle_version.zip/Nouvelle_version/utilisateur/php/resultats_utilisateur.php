<?php


session_start();

try {
    // On se connecte à MySQL
    $base = new PDO('mysql:host=localhost;dbname=bdd_icare;port=3308;charset=utf8', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
} catch (Exception $e) {
    // En cas d'erreur, on affiche un message et on arrête tout
    die('Erreur : ' . $e->getMessage());
}


?>
<?php
function resultats($base)
{

    $audition = '';
    $tonalite = '';
    $temp = '';
    $freq ='';
    $vue='';
    $reaction='';

    $data1 = '';

    $reponse = $base->prepare('SELECT `*` FROM resultats_test WHERE `N° Identité`= (SELECT `N° Identité` FROM identite WHERE `Nom d\'utilisateur` =:pseudo)' );
    $reponse->execute(array('pseudo'=>$_SESSION['username']));

    while ($donnees = $reponse->fetch()) {

        $tonalite = $tonalite . '' . $donnees['Tonalité'] . ',' ;
        $audition = $audition . '' . $donnees['Audition'] . ',' ;
        $temp = $temp . '' . $donnees['Température'] . ',' ;
        $freq = $freq . '' . $donnees['Fréquence cardiaque'] . ',' ;
        $vue = $vue . '' . $donnees['Vue'] . ',' ;
        $reaction = $reaction . '' . $donnees['Temps de réaction'] . ',' ;

        $data1 = $data1 . $audition . $temp . $tonalite . $freq . $vue . $reaction;

    }


    $reponse->closeCursor(); // Termine le traitement de la requête
    $data1 = trim($data1,",");
    return $data1;

}

function getName($base){

$reponse = $base->prepare('SELECT `Nom`, `Prénom` FROM identite WHERE `Nom d\'utilisateur` = :username' );
$reponse->execute(array('username' => $_SESSION['username']) );
$donnees = $reponse->fetch();
$name = $donnees['Prénom'] . ' ' . $donnees['Nom'];
$reponse->closeCursor();

return $name;
}

function test_reussi($base){

$reponse = $base->prepare('SELECT `Validité` FROM etat_du_test WHERE `N° Identité` = (SELECT `N° Identité` FROM identite WHERE  `Nom d\'utilisateur` = :username)');
$reponse->execute(array('username'=>$_SESSION['username']));
$donnees = $reponse->fetch();
$reponse->closeCursor();

if ($donnees['Validité'] == 'Réussi'){

    return 'TEST RÉUSSI';
}
else if ($donnees['Validité'] == 'Echec'){

    echo '<style type="text/css">
    #Validite {
        color: red;
    }
    </style>';
    return 'TEST ÉCHOUÉ';
}
else if ($donnees['Validité'] == 'En attente'){
    
    echo '<style type="text/css">
    #Validite {
        color: rgba(209,71,209,1);
    }
    </style>';
    return 'RÉSULTATS EN ATTENTE';
}
}




function getScore($base){

    $reponse = $base->prepare('SELECT `Score total` FROM resultats_test WHERE `N° Identité` = (SELECT `N° Identité` FROM identite WHERE  `Nom d\'utilisateur` = :username)');
    $reponse->execute(array('username'=>$_SESSION['username']));
    $donnees = $reponse->fetch();
    $reponse->closeCursor();

    return $donnees['Score total'];
}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Consulter les tests</title>
    <link rel= "stylesheet" href="../../header_footer/header_connecte.css" media="all" type="text/css">
    <link rel= "stylesheet" href="../css/compte_utilisateur.css" media="all" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
    <script src = "https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>


  </head>
  <header>
    <div class="bande">
        <nav class="utilisateur">
            <ul>
                <li class="rubriques" ><a href="../../login/php/login.php">Deconnexion</a></li>
                <li class="rubriques"><a href="../php/compte_utilisateur.php">Mon compte</a></li>
                <!-- lien vers les paramètres du comptes (différent pour chaque type de compte) -->
            </ul>
        </nav>
    </div>
    <div class="menu">
        <nav class="page-accueil">
          <ul>
            <li class="rubriques" ><a href="../../vitrine/php/accueil.php">Accueil</a></li>
            <li class="rubriques" ><a href="../../vitrine/html/infinite_measures.html">Infinite Measures & Vous</a></li>
            <li class="rubriques"><a href="../../vitrine/html/equipe.html">Notre Equipe</a></li>
            <li class="rubriques"><a href="stats.html">Nos Statistiques</a></li>
            <li class="rubriques"><a href="../php/forum_utilisateur.php">Forum</a></li>
        </ul>
        </nav>
    </div>
    <div class="perso">
        <nav class="page-accueil">
            <ul>
              <li class="rubriques1" ><a href="tbd_utilisateur.html">Tableau de bord</a></li>
              <li class="rubriques1" ><a href="resultats_utilisateur.html">Mes résultats</a></li>
              <li class="rubriques1"><a href="messagerie_utilisateur.html">Messagerie</a></li>
            </ul>
        </nav>
    </div>
</header>


  <body>

  <h2><?php echo getName($base); ?></h2>

<h3 id="Validite"><?php echo test_reussi($base); ?></h3>
<p id="monScore">Mon score : <span class="percent">0</span>/120</p>
<h4>Voir les résultats détaillés</h4>

<div class="scroll-arrow">
    <a href="resultats_utilisateur.php#flexBox"><img src="https://cssanimation.rocks/levelup/public/images/downarrow.png" width="50"></a>
</div>


<div id = "flexBox" class ="flexBox">
    <div class="container">

        <canvas id="myChart"></canvas>

    </div>


    <div class="container">

        <canvas id="myResult"></canvas>

    </div>

   

</div>

<div id="resumeFlex" class ="flexBox">
<p class="resume"> Meilleur temps de réaction : <span class="green">0.24</span>s </p>          
<p class="resume">98% des utilisateurs ont un moins bon score</p>
<p class="resume">Bande de fréquence audible : <span class="green">30Hz - 1224Hz</span></p>

</div>







<script>

    Chart.defaults.global.defaultFontFamily = 'Lato';
    Chart.defaults.global.defaultFontSize = 18;
    Chart.defaults.global.defaultFontColor = '#777';
    Chart.defaults.global.elements.point.radius = 6;
    Chart.defaults.global.elements.point.backgroundColor = 'rgba(35, 165, 246, 0.9)';
    Chart.defaults.global.elements.line.backgroundColor='rgb(135,206,250,0.7)';
    Chart.defaults.global.elements.line.borderColor='rgb(35,165,246,0.9)';



    let myChart = document.getElementById('myChart').getContext('2d');
    let myResult = document.getElementById('myResult').getContext('2d');

    let percentSuccessChart = new Chart(myChart, {

        type:'bar',
        data:{
            labels:['Audition','Température','Tonalité','Fréquence cardiaque','Vue','Temps de réaction'],
            datasets:[{
                label:'',
                data:[
                    <?php echo resultats($base);?>
                ],
                backgroundColor :[
                    'rgba(255, 99, 132, 0.6)',
            'rgba(54, 162, 235, 0.6)',
            'rgba(255, 206, 86, 0.6)',
            'rgba(75, 192, 192, 0.6)',
            'rgba(153, 102, 255, 0.6)',
            'rgba(255, 159, 64, 0.6)',
            'rgba(255, 99, 132, 0.6)'
                
                
                
                ],
                
            }]


        },
        options: {
            responsive: true,
            
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }   
    });
    

    let percentResultChart = new Chart(myResult, {

        type:'line',
        data:{
            labels:['1', '2', '3', '4', '5','6','7','8','9','10'],
            datasets:[{
                label:'Battements par minute',
                data:[
                    84,85,84,88,86,81,89,84,84,87
                ],
                pointHoverRadius:9             
                
            }]


        },
        options: {
            responsive: true,
            
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }   
    });


    // Use requestAnimationFrame with setTimeout fallback
    window.requestAnimFrame = (function () {
        return  window.requestAnimationFrame ||
            window.webkitRequestAnimationFrame ||
            window.mozRequestAnimationFrame ||
            window.oRequestAnimationFrame ||
            window.msRequestAnimationFrame ||
            function (callback) {
                window.setTimeout(callback, 1000 / 60);
            };
    })();

    var percentEl = document.querySelector('.percent');
    var max = <?php echo getScore($base);?>;

    (function animloop() {
        if (percentEl.innerHTML >= max) { return; } //Stop recursive when max reach
        requestAnimFrame(animloop);
        percentEl.innerHTML++;
    })();


</script>
  </body>


  <footer class="footer-distributed">

    <div class="footer-left">
            <h3>I<span>Care</span></h3>
            <p class="footer-links">
              <a href="../../vitrine/html/faq.html">FAQ</a>
            .
            <a href="mentions.html">Mentions Légales</a>
        </br>



            <a href="#">Langues</a> -

            <a href="#2">Anglais</a>
        .
            <a href="#2">Français</a>


            </p>

            <p class="footer-company-name">Icare &copy; 2020</p>
            </div>

            <div class="footer-center">

            <div>
            <i class="fa fa-map-marker"></i>
            <p>10 Rue de Vanves</br> Issy-les-Moulineaux, France</p>
            </div>

            <div>
            <i class="fa fa-phone"></i>
            <p>+33 6 68 61 24 99</p>
            </div>

            <div>
            <i class="fa fa-envelope"></i>
            <p><a href="mailto:support@company.com">youandicare.supp@gmail.com</a></p>
            </div>

            </div>

            <div class="footer-right">

            <p class="footer-company-about">
            <span>About the company</span>
            <iframe class="API" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2626.7658445478332!2d2.2776649150477297!3d48.82452897928419!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e670797ea4730d%3A0xe0d3eb2ad501cb27!2sISEP!5e0!3m2!1sfr!2sfr!4v1583759492983!5m2!1sfr!2sfr" width="400" height="200" frameborder="0" style="border:0;" allowfullscreen=""></iframe>

            </p>
            </div>
  </footer>
</html>